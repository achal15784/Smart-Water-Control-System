volatile unsigned long pulseCount = 0;

// Replace with your calibrated value
const float K = 372;

void IRAM_ATTR pulseCounter() {
  pulseCount++;
}

void setup() {
  Serial.begin(115200);

  pinMode(27, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(27),
    pulseCounter,
    RISING
  );

  Serial.println("Flow Meter Started");
  Serial.println("Send 'r' to reset pulse count");
}

void loop() {

  // Reset command
  if (Serial.available()) {
    char c = Serial.read();

    if (c == 'r' || c == 'R') {
      pulseCount = 0;
      Serial.println("Pulse Count Reset!");
    }
  }

  float volumeLiters = pulseCount / K;

  Serial.print("Pulses: ");
  Serial.print(pulseCount);

  Serial.print(" | Volume: ");
  Serial.print(volumeLiters, 3);
  Serial.println(" L");

  delay(1000);
}