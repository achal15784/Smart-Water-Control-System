volatile unsigned long pulseCount = 0;

void IRAM_ATTR pulseCounter() {
  pulseCount++;
}

void setup() {
  Serial.begin(115200);

  pinMode(27, INPUT_PULLUP);   // Flow sensor signal pin

  attachInterrupt(
    digitalPinToInterrupt(27),
    pulseCounter,
    RISING
  );

  Serial.println("YF-S201 Pulse Counter Started");
  Serial.println("Send 'r' in Serial Monitor to reset count");
}

void loop() {

  if (Serial.available()) {
    char c = Serial.read();

    if (c == 'r' || c == 'R') {
      pulseCount = 0;
      Serial.println("Pulse Count Reset");
    }
  }

  static unsigned long lastTime = 0;

  if (millis() - lastTime >= 1000) {
    lastTime = millis();

    Serial.print("Total Pulses: ");
    Serial.println(pulseCount);
  }
}